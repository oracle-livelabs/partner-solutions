
# for help, run:
# python3 help.py

# config file path
config_file_path="/home/.oci/config"
# config file profile
config_profile="DEFAULT"
# region identifier of DLS Dataset
# for example: eu-frankfurt-1
region_identifier="< YOUR REGION >"
# compartment where DLS Dataset exists
compartment_id = "ocid1.compartment.oc1.... <YOUR COMPARTMENT OCID> ..."
# ocid of the DLS Dataset
dataset_id = "ocid1.datalabelingdataset.oc1.eu-frankfurt-1.... <YOUR DATASET OCID> ..."
# an array where the elements are all of the labels that you will use to annotate records in your DLS Dataset with. Each element is a separate label.
labels = ["NORMAL", "PNEUMONIA"]
# the algorithm that will be used to assign labels to DLS Dataset records
labeling_algorithm = "first_match"
# use for first_match labeling algorithm
first_match_regex_pattern = r'^([^/]*)/.*$'
# maximum number of DLS Dataset records that can be retrieved from the list_records API operation for labeling
# limit=1000 is the hard limit for list_records
list_records_limit = 1000
